#include "Tetromino.h"
#include "TetrisWindow.h"



int main()
{
	/********************************************************/
		//Opprett vindu her

	TetrisWindow window;
	window.run();
    /********************************************************/
        //kall run på det her
	return 0;
}
